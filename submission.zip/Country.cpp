//
// Created by omar_ on 16/02/2024.
//

#include "Country.h"

Country::Country(int countryID, int medals) : Item(countryID), numberOfContestants(0), numberOfTeams(0), medals(medals){}



int Country::getMedals() const {
    return medals;
}

int Country::getNumberOfContestants() const {
    return numberOfContestants;
}

int Country::getNumberOfTeams() const {
    return numberOfTeams;
}

void Country::addTeam(){
    numberOfTeams++;
}
void Country::addContestant(){
    numberOfContestants++;
}

void Country::removeTeam() {
    numberOfTeams--;
}

void Country::removeContestant() {
    numberOfContestants--;
}

void Country::addMedal() {
    medals++;
}

//void addContestant(shared_ptr<Contestant>& contestant){
////    contestants.insert(contestant->getID());
////    numberOfContestants++;
////    strength += contestant->getStrength();
////    myContestants->insert(contestant);
//
//}